$('#search_0').on('keyup', function(){
    search($('#search_0').val());
});

$('#search_1').on('keyup', function(){
    search($('#search_1').val());
});

search();
function search(val){
     var keyword = val;
     $.post('/search',
      {
         _token: $('meta[name="csrf-token"]').attr('content'),
         keyword:keyword
       },
       function(data){
        search_bps_ri(data.lists_bps_ri);
        search_bps_aceh(data.lists_bps_aceh);
        search_bps_kabkot(data.lists_bps_kabkot);
        //   console.log(data.lists_bps_ri.length);
       });
}

// table row with ajax
function search_bps_ri(res){
    let bps_ri = '';

    if(res.length <= 0){
        bps_ri += 
        `
            <p class="text-gray-500 w-full col-span-full" style="width:200px">Aplikasi tidak ditemukan</p>   
        `;
    } else {
        res.forEach(element => {
            bg_akses = 
            bps_ri += 
            `
            <div class="item flex flex-col rounded-lg bg-white hover:shadow-xl shadow-lg p-3 gap-x-5" data-id=${element.id}>
                <a href="${element.link}" target="_blank" class="hit-button">
                    <div class="flex items-center justify-center rounded-lg">
                        <img src="img/${element.logo}" alt="" class="rounded-lg">
                    </div>
                    <div class="flex flex-col justify-between h-full">
                        <div>
                            <p class="my-2 font-semibold">${element.nama}</p>
                            <span class="${element.akses === "publik" ? "bg-[#4bc58e] text-[#fffffff3]":"bg-[#F1A67E] text-[#fffffff3]"} rounded-md px-1 text-xs">akses ${element.akses}</span>
                            <p class="pb-1 text-sm text-gray-500">
                                Hits: <span id="hits-count-${element.id}">${element.hits}</span> kali
                            </p>
                            <p class="text-sm">${element.deskripsi}</p>
                        </div>
                    </div>
                </a>
            </div>   
            `;
        });
    }
    
     $('#bps_ri').html(bps_ri);
}

function search_bps_aceh(res){
    let bps_aceh = '';

    if(res.length <= 0){
        bps_aceh += 
        `
            <p class="text-gray-500 col-span-full" style="width:200px">Aplikasi tidak ditemukan</p>   
        `;
    } else {
        res.forEach(element => {
            bps_aceh += 
            `
            <div class="item flex flex-col rounded-lg bg-white hover:shadow-xl shadow-lg p-3 gap-x-5" data-id=${element.id}>
                <a href="${element.link}" target="_blank" class="hit-button">    
                    <div class="flex items-center justify-center rounded-lg">
                        <img src="img/${element.logo}" alt="" class="rounded-lg">
                    </div>
                    <div class="flex flex-col justify-between h-full">
                        <div>
                            <p class="my-2 font-semibold">${element.nama}</p>
                            <span class="${element.akses === "publik" ? "bg-[#4bc58e] text-[#fffffff3]":"bg-[#F1A67E] text-[#fffffff3]"} rounded-md px-1 text-xs">akses ${element.akses}</span>
                            <p class="pb-1 text-sm text-gray-500">
                                Hits: <span id="hits-count-${element.id}">${element.hits}</span> kali
                            </p>
                            <p class="text-sm">${element.deskripsi}</p>
                        </div>
                    </div>
                </a>
            </div>   
            `;
        });
    }
    
     $('#bps_aceh').html(bps_aceh);
}

function search_bps_kabkot(res){
    let bps_kabkot = '';

    if(res.length <= 0){
        bps_kabkot += 
        `
            <p class="text-gray-500 col-span-full" style="width:200px">Aplikasi tidak ditemukan</p>   
        `;
    } else {
        res.forEach(element => {
            bps_kabkot += 
            `
            <div class="item flex flex-col rounded-lg bg-white hover:shadow-xl shadow-lg p-3 gap-x-5" data-id=${element.id}>
                <a href="${element.link}" target="_blank" class="hit-button">
                    <div class="flex items-center justify-center rounded-lg">
                        <img src="img/${element.logo}" alt="" class="rounded-lg">
                    </div>
                    <div class="flex flex-col justify-between h-full">
                        <div>
                            <p class="mt-2 mb-1 font-semibold">${element.nama}</p>
                            <span class="bg-fuchsia-200 rounded-md px-1 text-xs">${element.pembuat}</span>
                            <br><span class="${element.akses === "publik" ? "bg-[#4bc58e] text-[#fffffff3]":"bg-[#F1A67E] text-[#fffffff3]"} rounded-md px-1 text-xs">akses ${element.akses}</span>
                            <p class="pb-1 text-sm text-gray-500">
                                Hits: <span id="hits-count-${element.id}">${element.hits}</span> kali
                            </p>
                            <p class="text-sm">${element.deskripsi}</p>
                        </div>
                    </div>
                </a>
            </div>   
            `;
        });
    }
    
     $('#bps_kabkot').html(bps_kabkot);
}

$(document).ready(function() {
    $(document).on('click', '.hit-button', function(e) {
        e.preventDefault(); // Mencegah tindakan default sementara
        console.log("Button clicked");
        
        var id = $(this).closest('.item').data('id');
        var url = $(this).attr('href'); // Ambil URL dari atribut href

        $.ajax({
            url: '/updatehits',  // Sesuaikan URL dengan rute Anda
            type: 'POST',
            data: {
                _token: $('meta[name="csrf-token"]').attr('content'),
                item_id: id
            },
            success: function(response) {
                console.log(response);
                const hitCountElement = $(`#hits-count-${id}`);
                if (hitCountElement.length > 0) {
                    hitCountElement.text(parseInt(hitCountElement.text()) + 1);
                } else {
                    console.error(`Element with ID hits-count-${id} not found`);
                }
                // Setelah sukses, buka link di tab baru
                window.open(url, '_blank');
            },
            error: function(xhr, status, error) {
                console.error('Error updating hit count:', xhr.responseText);
                // Jika ada error, tetap buka link di tab baru
                window.open(url, '_blank');
            }
        });
    });
});

document.addEventListener('DOMContentLoaded', function () {
    function setupToggle(toggleButtonId, contentId) {
        const toggleButton = document.getElementById(toggleButtonId);
        const content = document.getElementById(contentId);
        const chevronIcon = toggleButton.querySelector('.chevron');

        toggleButton.addEventListener('click', function () {
            if (content.classList.contains('max-height-full')) {
                content.classList.remove('max-height-full');
                content.classList.remove('initial-max-height-full');
                chevronIcon.classList.remove('chevron-up');
                chevronIcon.classList.add('chevron-down');
            } else {
                content.classList.add('max-height-full');
                content.classList.remove('initial-max-height-full');
                chevronIcon.classList.remove('chevron-down');
                chevronIcon.classList.add('chevron-up');
            }
        });
    }

    setupToggle('toggle-chevron', 'bps_ri');
    setupToggle('toggle-chevron-aceh', 'bps_aceh');
    setupToggle('toggle-chevron-kab', 'bps_kabkot');

});