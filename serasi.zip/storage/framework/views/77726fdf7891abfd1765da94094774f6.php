

<?php $__env->startSection('content'); ?>
    <p class="font-semibold mb-4 text-center text-lg">Tambah Aplikasi Baru</p>
    <form action="/update/<?php echo e($apps->id); ?>" enctype="multipart/form-data" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="grid grid-cols-2 gap-x-4">
            <div>
                <label for="nama">Nama Aplikasi</label>
                <input type="text" name="nama" value="<?php echo e($apps->nama); ?>" class="w-full px-4 py-2 border border-[#CEABA5] rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-300">
            </div>
            <div>
                <label className="block mb-2 font-medium">Pengguna</label>
                <select id="pengguna" name="pengguna" class="block w-full px-4 py-2 border border-[#CEABA5] bg-white rounded-lg shadow-sm focus:outline-none focus:ring-1 focus:ring-blue-300 focus:border-blue-500">
                    <option value="" disabled selected>Pilih Pengguna</option>
                    <option value="BPS Selindo" <?php echo e($apps->pengguna =="BPS Selindo" ? "selected" : ""); ?>>BPS Selindo</option>
                    <option value="BPS Se-Aceh"  <?php echo e($apps->pengguna =="BPS Se-Aceh" ? "selected" : ""); ?>>BPS Se-Aceh</option>
                    <option value="BPS Provinsi Saja"  <?php echo e($apps->pengguna =="BPS Provinsi Saja" ? "selected" : ""); ?>>BPS Provinsi Saja</option>
                    <option value="BPS satker kako pembuat saja" <?php echo e($apps->pengguna =="BPS satker kako pembuat saja" ? "selected" : ""); ?>>BPS satker kako pembuat saja</option>
                </select>
            </div>
        </div>
        <div class="grid grid-cols-2 gap-x-4">
            <div class="mt-4">
                <label className="block mb-2 font-medium">Akses</label>
                <select id="akses" name="akses" class="block w-full px-4 py-2 border border-[#CEABA5] bg-white rounded-lg shadow-sm focus:outline-none focus:ring-1 focus:ring-blue-300 focus:border-blue-500">
                    <option value="" disabled selected>Pilih Akses</option>
                    <option value="publik" <?php echo e($apps->akses == "publik" ? "selected" : ""); ?>>Publik</option>
                    <option value="vpn" <?php echo e($apps->akses == "vpn" ? "selected" : ""); ?>>VPN</option>
                </select>
            </div>
            <div class="mt-4">
                <label className="block mb-2 font-medium">Pengembang</label>
                <select id="pembuat" name="pembuat" class="block w-full px-4 py-2 border border-[#CEABA5] bg-white rounded-lg shadow-sm focus:outline-none focus:ring-1 focus:ring-blue-300 focus:border-blue-500">
                    <option value="" disabled selected>Pilih Kabupaten/Kota</option>
                    <option value="BPS RI" <?php echo e($apps->pembuat =="BPS RI" ? "selected" : ""); ?>>BPS RI</option>
                    <option value="BPS Aceh" <?php echo e($apps->pembuat =="BPS Aceh" ? "selected" : ""); ?>>BPS Aceh</option>
                    <option value="Aceh Barat" <?php echo e($apps->pembuat =="BPS Se-Aceh" ? "selected" : ""); ?>>BPS Aceh Barat</option>
                    <option value="Aceh Barat Daya" <?php echo e($apps->pembuat == "Aceh Barat Daya" ? "selected" : ""); ?>>BPS Aceh Barat Daya</option>
                    <option value="Aceh Besar" <?php echo e($apps->pembuat == "Aceh Besar" ? "selected" : ""); ?>>BPS Aceh Besar</option>
                    <option value="Aceh Jaya" <?php echo e($apps->pembuat == "Aceh Jaya" ? "selected" : ""); ?>>BPS Aceh Jaya</option>
                    <option value="Aceh Selatan" <?php echo e($apps->pembuat == "Aceh Selatan" ? "selected" : ""); ?>>BPS Aceh Selatan</option>
                    <option value="Aceh Singkil" <?php echo e($apps->pembuat == "Aceh Singkil" ? "selected" : ""); ?>>BPS Aceh Singkil</option>
                    <option value="Aceh Tamiang" <?php echo e($apps->pembuat == "Aceh Tamiang" ? "selected" : ""); ?>>BPS Aceh Tamiang</option>
                    <option value="Aceh Tengah" <?php echo e($apps->pembuat == "Aceh Tengah" ? "selected" : ""); ?>>BPS Aceh Tengah</option>
                    <option value="Aceh Tenggara" <?php echo e($apps->pembuat == "Aceh Tenggara" ? "selected" : ""); ?>>BPS Aceh Tenggara</option>
                    <option value="Aceh Timur" <?php echo e($apps->pembuat == "Aceh Timur" ? "selected" : ""); ?>>BPS Aceh Timur</option>
                    <option value="Aceh Utara" <?php echo e($apps->pembuat == "Aceh Utara" ? "selected" : ""); ?>>BPS Aceh Utara</option>
                    <option value="Banda Aceh" <?php echo e($apps->pembuat == "Banda Aceh" ? "selected" : ""); ?>>BPS Banda Aceh</option>
                    <option value="Bener Meriah" <?php echo e($apps->pembuat == "Bener Meriah" ? "selected" : ""); ?>>BPS Bener Meriah</option>
                    <option value="Bireuen" <?php echo e($apps->pembuat == "Bireuen" ? "selected" : ""); ?>>BPS Bireuen</option>
                    <option value="Gayo Lues" <?php echo e($apps->pembuat == "Gayo Lues" ? "selected" : ""); ?>>BPS Gayo Lues</option>
                    <option value="Langsa" <?php echo e($apps->pembuat == "Langsa" ? "selected" : ""); ?>>BPS Langsa</option>
                    <option value="Lhokseumawe" <?php echo e($apps->pembuat == "Lhokseumawe" ? "selected" : ""); ?>>BPS Lhokseumawe</option>
                    <option value="Nagan Raya" <?php echo e($apps->pembuat == "Nagan Raya" ? "selected" : ""); ?>>BPS Nagan Raya</option>
                    <option value="Pidie" <?php echo e($apps->pembuat == "Pidie" ? "selected" : ""); ?>>BPS Pidie</option>
                    <option value="Pidie Jaya" <?php echo e($apps->pembuat == "Pidie Jaya" ? "selected" : ""); ?>>BPS Pidie Jaya</option>
                    <option value="Sabang" <?php echo e($apps->pembuat == "Sabang" ? "selected" : ""); ?>>BPS Sabang</option>
                    <option value="Simeulue" <?php echo e($apps->pembuat == "Simeulue" ? "selected" : ""); ?>>BPS Simeulue</option>
                    <option value="Subulussalam" <?php echo e($apps->pembuat == "Subulussalam" ? "selected" : ""); ?>>BPS Subulussalam</option>
                </select>
            </div>     
        </div>
        <div class="mt-4">
            <label for="link">Link Aplikasi</label>
            <input type="text" value="<?php echo e($apps->link); ?>" name="link" class="w-full px-4 py-2 border border-[#CEABA5] rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-300">
        </div>
        <div class="mt-4">
            <label for="deskripsi">Deskripsi Aplikasi</label>
            <textarea name="deskripsi" id="" class="w-full px-4 py-2 border border-[#CEABA5] rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-300" rows="3">
                <?php echo e($apps->deskripsi); ?>

            </textarea>
        </div>
        <div class="mt-4">
            <label for="logo">Logo Aplikasi</label>
            <input type="file" name="logo" class="w-full px-4 py-2 border border-[#CEABA5] rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-300">
            <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-600 text-sm"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button type="submit" class="w-full bg-blue-500 rounded-lg mt-4 py-2 text-white">Submit</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Code\Web Programming\Project\serasi-bpsaceh\resources\views/update.blade.php ENDPATH**/ ?>