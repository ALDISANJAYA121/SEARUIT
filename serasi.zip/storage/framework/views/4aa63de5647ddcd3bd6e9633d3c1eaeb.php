<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <title>SERASI | Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <script src="/js/jquery.min.js"></script>
    <link rel="stylesheet" href="/css/datatables_edit.css">
    
    

</head>
<body>
    <div class="w-full lg:px-10 h-14 sticky bg-blue-900 text-white flex flex-row justify-between items-center">
        <div>
          <a href="/" class="text-white font-bold text-2xl italic">SERASI</a>
        </div>
        <div class="flex flex-row space-x-4">
          <a href="/" class="text-white">Home</a>
          <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="text-white hover:text-red-500">Logout</button>
          </form>
        </div>
      </div>
    <div class="p-10 overflow-auto">
        <?php echo $__env->yieldContent('content'); ?>
     </div>

     <script src="/js/jquery.dataTables.min.js"></script>
</body><?php /**PATH D:\Code\Web Programming\Project\serasi-bpsaceh\resources\views/layout_admin.blade.php ENDPATH**/ ?>