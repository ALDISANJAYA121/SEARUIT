

<?php $__env->startSection('content'); ?>
    
      <h1 class="text-xl font-semibold mb-6 text-center">Daftar Seluruh Aplikasi BPS Se-Aceh</h1>
      <div class="mb-6">
        <a href="/tambah" class="bg-blue-500 text-white p-2 rounded-lg text-center">Tambah Aplikasi</a>
      </div>
      <table id="example" class="w-screen table-auto">
          <thead>
              <tr class="bg-gray-2 text-left border-b bg-blue-300">
                  <th class="py-4 px-4 font-medium text-black xl:pl-11 text-center">
                    Nama
                  </th>
                  <th class="py-4 px-4 font-medium text-black text-center">
                    Link
                  </th>
                  <th class="py-4 px-4 font-medium text-black text-center">
                    Deskripsi
                  </th>
                  <th class="py-4 px-4 font-medium text-black text-center">
                    Pengguna
                  </th>
                  <th class="py-4 px-4 font-medium text-black text-center">
                    Pengembang
                  </th>
                  <th class="py-4 px-4 font-medium text-black text-center">
                    Akses
                  </th>
                  <th class="py-4 px-4 font-medium text-black text-center">
                    Hits
                  </th>
                  <th class="py-4 px-4 font-medium text-black text-center">
                    Aksi
                  </th>
                </tr>
          </thead>
          <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                  <td class="border-b border-[#eee]">
                      <p class="text-black"><?php echo e($item->nama); ?></p>
                    </td>
                    <td class="border-b border-[#eee]">
                      <p class="text-black"><?php echo e($item->link); ?></p>
                    </td>
                    <td class="border-b border-[#eee]">
                      <p class="text-black"><?php echo e($item->deskripsi); ?></p>
                    </td>
                    <td class="border-b border-[#eee]">
                      <p class="text-black"><?php echo e($item->pengguna); ?></p>
                    </td>
                    <td class="border-b border-[#eee]">
                      <p class="text-black"><?php echo e($item->pembuat); ?></p>
                    </td>
                    <td class="border-b border-[#eee]">
                      <p class="text-black"><?php echo e($item->akses); ?></p>
                    </td>
                    <td class="border-b border-[#eee]">
                      <p class="text-black"><?php echo e($item->hits); ?></p>
                    </td>
                    <td class="border-b border-[#eee]">
                      <div class="cursor-pointer">
                        <a href="edit/<?php echo e($item->id); ?>" class="bg-yellow-500 text-white px-2 text-sm rounded-lg">Ubah</a>
                        <form method="post" action="delete/<?php echo e($item->id); ?>">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field("DELETE"); ?>
                          <button type="submit" class="bg-red-500 text-white px-2 text-sm rounded-lg">Hapus</button>
                        </form>
                      </div>
                    </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  
              <?php endif; ?>
          </tbody>
      </table>
    </div>

    <link rel="stylesheet" href="/css/jquery.dataTables.min.css">
    <script src="/js/jquery.dataTables.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    
    <script>
          $(document).ready(function() {
            $('#example').DataTable({
                // Add any customization options here
            });
        });

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Code\Web Programming\Project\serasi-bpsaceh\resources\views/admin.blade.php ENDPATH**/ ?>