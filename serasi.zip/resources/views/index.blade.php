<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>SERASI</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet">
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-002CQCMVP4"></script>

        <meta name="csrf-token" content="{{ csrf_token() }}">

        <link href="{{ asset('css/app.css') }}" rel="stylesheet">
        <link rel="stylesheet" href="/css/carousel.css">

        {{-- <meta http-equiv="Content-Security-Policy" content="default-src 'self'"/> --}}
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
          
            gtag('config', 'G-002CQCMVP4');
          </script>
    </head>
    <body>
        <div class="lg:grid lg:grid-cols-12 flex lg:flex-row flex-col-reverse lg:h-screen h-auto overflow-auto">
            <div class="lg:col-span-5 lg:pr-3 lg:pl-5 lg:py-8 md:p-12 px-4 pt-0 pb-4 overflow-auto custom-scrollbar">
                <div class="lg:block hidden">
                    <h3 class="text-5xl font-bold text-center">SERASI</h3><br>
                    <p class="-mt-5 text-lg text-center">Serambi Aplikasi BPS se-Provinsi Aceh</p>
                </div>
                <div class="lg:relative lg:block hidden my-6 w-full">
                    <input id="search_0" type="text" placeholder="Cari aplikasi.." class="w-full px-4 py-2 border border-[#CEABA5] rounded-lg focus:outline-none focus:border-[#9D262A] focus:ring-1 focus:ring-[#9D262A]">
                    <img src="/img/search.svg" alt="Search" class="absolute top-1/2 right-3 transform -translate-y-1/2 w-5 h-5">
                </div>        

                <div class="flex items-center justify-between mt-6 bg-[#C1AEDE] rounded-sm px-3 pt-1 mb-3">
                    <h3 class="font-semibold text-xl mb-2">BPS RI</h3>
                    <button id="toggle-chevron" class="focus:outline-none">
                        <svg class="w-6 h-6 chevron chevron-up" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                        </svg>
                    </button>
                </div>
                <div id="bps_ri" class="grid sm:grid-cols-3 grid-cols-2 gap-3 h-96 custom-scrollbar max-height-full transition-max-height duration-500 ease-in-out">
                    @foreach ($lists_bps_ri as $item)
                        <div class="item flex flex-col rounded-lg bg-white hover:shadow-xl shadow-lg p-3 gap-x-5" data-id={{ $item->id }}>
                            <a href="{{ $item->link }}" target="_blank" class="hit-button">
                                <div class="flex items-center justify-center rounded-lg">
                                    <img src="img/{{ $item->logo }}" alt="" class="rounded-lg">
                                </div>
                                <div class="flex flex-col justify-between h-full">
                                    <div>
                                        <p class="my-2 font-semibold">{{ $item->nama }}</p>
                                        <span class="{{ $item->akses == "publik" ? "bg-[#4bc58e] text-[#fffffff3]":"bg-[#F1A67E] text-[#fffffff3]" }} rounded-md px-1 text-xs">akses {{ $item->akses }}</span>
                                        <p class="pb-1 text-sm text-gray-500">Hits: {{ $item->hits }} kali</p>
                                        <p class="text-sm">{{ $item->deskripsi }}</p>
                                    </div>
                                </div>
                            </a>
                        </div>      
                    @endforeach
                </div>
                
                <div class="flex items-center justify-between mt-3 bg-[#4bc58e] rounded-sm px-3 pt-1 mb-3">
                    <h3 class="font-semibold text-xl mb-2">BPS PROVINSI ACEH</h3>
                    <button id="toggle-chevron-aceh" class="focus:outline-none">
                        <svg class="w-6 h-6 chevron chevron-up" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                        </svg>
                    </button>
                </div>
                <div id="bps_aceh" class="grid sm:grid-cols-3 grid-cols-2 gap-3 h-96 custom-scrollbar max-height-full transition-max-height duration-500 ease-in-out">
                    @foreach ($lists_bps_aceh as $item)
                        <div class="item flex flex-col rounded-lg bg-white hover:shadow-xl shadow-lg p-3 gap-x-5" data-id={{ $item->id }}>
                            <a href="{{ $item->link }}" target="_blank" class="hit-button">
                                <div class="flex items-center justify-center rounded-lg">
                                    <img src="img/{{ $item->logo }}" alt="" class="rounded-lg">
                                </div>
                                <div class="flex flex-col justify-between h-full">
                                    <div>
                                        <p class="my-2 font-semibold">{{ $item->nama }}</p>
                                        <span class="{{ $item->akses == "publik" ? "bg-[#4bc58e] text-[#fffffff3]":"bg-[#F1A67E] text-[#fffffff3]" }} rounded-md px-1 text-xs">akses {{ $item->akses }}</span>
                                        <p class="pb-1 text-sm text-gray-500">Hits: {{ $item->hits }} kali</p>
                                        <p class="text-sm">{{ $item->deskripsi }}</p>
                                    </div>
                                </div>
                            </a>
                        </div>      
                    @endforeach
                </div>
                
                <div class="flex items-center justify-between mt-3 bg-[#E5D1DA] rounded-sm px-3 pt-1 mb-3">
                    <h3 class="font-semibold text-xl mb-2">BPS KABUPATEN/KOTA</h3>
                    <button id="toggle-chevron-kab" class="focus:outline-none">
                        <svg class="w-6 h-6 chevron chevron-up" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                        </svg>
                    </button>
                </div>
                <div id="bps_kabkot" class="grid sm:grid-cols-3 grid-cols-2 gap-3 h-96 custom-scrollbar max-height-full transition-max-height duration-500 ease-in-out">
                    @foreach ($lists_bps_kabkot as $item)
                        <div class="item flex flex-col rounded-lg bg-white hover:shadow-xl shadow-lg p-3 gap-x-5" data-id={{ $item->id }}>
                            <a href="{{ $item->link }}" target="_blank" class="hit-button">
                                <div class="flex items-center justify-center rounded-lg">
                                    {{-- {{ $item->logo }} --}}
                                    <img src="img/{{ $item->logo }}" alt="" class="rounded-lg">
                                </div>
                                <div class="flex flex-col justify-between h-full">
                                    <div>
                                        <span class="bg-fuchsia-200 rounded-md px-1 text-xs">{{ $item->pembuat }}</span>
                                        <br><span class="{{ $item->akses == "publik" ? "bg-[#4bc58e] text-[#fffffff3]":"bg-[#F1A67E] text-[#fffffff3]" }} rounded-md px-1 text-xs">akses {{ $item->akses }}</span>
                                        <p class="my-2 font-semibold">{{ $item->nama }}</p>
                                        <p class="pb-1 text-sm text-gray-500">
                                            Hits: {{ $item->hits }} kali
                                        </p>
                                        <p class="text-sm">{{ $item->deskripsi }}</p>
                                    </div>
                                </div>
                            </a>
                        </div>       
                    @endforeach
                </div>
            </div>
            <div class="lg:col-span-7">
                <div class="fixed w-full top-0 z-50 bg-[#F4F4F4]">
                    <div class="lg:hidden block mt-5 rounded-lg py-1 bg-[#1EA05E] text-white mx-4">
                        <h3 class="md:text-5xl text-3xl font-bold lg:text-start text-center">SERASI</h3><br>
                        <p class="-mt-5 md:text-lg text-sm lg:text-start text-center">Serambi Aplikasi BPS se-Provinsi Aceh</p>
                    </div>
                    <div class="lg:hidden relative px-4 my-3 w-full">
                        <input id="search_1" type="text" placeholder="Cari aplikasi.." class="search_app w-full px-4 py-2 border border-[#CEABA5] rounded-lg focus:outline-none focus:border-[#9D262A] focus:ring-1 focus:ring-[#9D262A]">
                        <img src="/img/search.svg" alt="Search" class="absolute top-1/2 right-6 transform -translate-y-1/2 w-5 h-5">
                    </div>  
                </div>
                <div class="carousel lg:mt-0 md:mt-40 sm:mt-48 mt-36">
                    <div class="list">

                        <?php 
                            $order = [10,1,2,3,4,5,6,7,8,9];
                            $i = 0;
                        ?>
                        @foreach ($tophits as $item)
                            <div class="item">
                                <img src="img/{{ $item['logo'] }}" class="rounded-lg">
                                <div class="introduce">
                                    <div class="title">#TOPHITS NO {{ $order[$i] }}</div>
                                    <div class="topic">{{ $item['nama'] }}</div>
                                    <span id="pembuat" class="bg-[#1EA05E] rounded-md px-2 text-white text-xs">{{ $item['pembuat'] }}</span>
                                    <div class="des">
                                        <!-- 20 lorem -->
                                        Hits : {{ $item["hits"] }}
                                        <div class="text-sm text-black mb-14">{{ $item['deskripsi'] }}</div>
                                    </div>
                                    <a href="https://aceh.bps.go.id" class="seeMore" target="_blank">Kunjungi &#8599</a>
                                </div>
                            </div>
                            <?php $i++ ?>
                        @endforeach

                    </div>
                    <div class="arrows">
                        <button id="prev"><</button>
                        <button id="next">></button>
                        {{-- <button id="back">See All  &#8599</button> --}}
                    </div>
                </div>
            </div>
        </div>
        <script src="/js/jquery.min.js"></script>
        <script src="/js/app.js"></script>
        <script src="/js/script.js"></script>
        <script src="/js/carousel.js"></script>
    </body>
</html>
